import PageIntro from "../components/PageIntro";

function About() {
  return (
    <div className="about-page">

      <PageIntro
        title="About Cybervault IT Centre"
        description="Discover who we are and what drives our passion for technology."
      />

      <section>
        <h2>Who We Are</h2>

        <p>
          Cybervault IT Centre is a technology-focused organization
          committed to providing innovative digital solutions.
          We help individuals and businesses solve problems through
          modern technology.
        </p>
      </section>

      <section>
        <h2>Our Mission</h2>

        <p>
          To empower individuals and businesses through accessible,
          secure and innovative technology solutions.
        </p>
      </section>

      <section>
        <h2>Our Vision</h2>

        <p>
          To become a globally recognized technology centre known
          for innovation, excellence and digital transformation.
        </p>
      </section>

      <section>
        <h2>Our Core Values</h2>

        <ul>
          <li>Innovation</li>
          <li>Integrity</li>
          <li>Professionalism</li>
          <li>Customer satisfaction</li>
          <li>Continuous learning</li>
        </ul>
      </section>

    </div>
  );
}

export default About;