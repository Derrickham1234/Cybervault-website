import PageIntro from "../components/PageIntro";

function Gallery() {
  return (
    <div className="gallery-page">

      <PageIntro
        title="Our Gallery"
        description="Explore technology, innovation and the world of Cybervault IT Centre."
      />

      <section className="gallery-container">

        <div className="gallery-item">
          <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600" alt="Web development workspace" />
          <h3>Web Development</h3>
        </div>

        <div className="gallery-item">
          <img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600" alt="Technology workspace" />
          <h3>Digital Technology</h3>
        </div>

        <div className="gallery-item">
          <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600" alt="Cybersecurity technology" />
          <h3>Cybersecurity</h3>
        </div>

        <div className="gallery-item">
          <img src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=600" alt="Team working together" />
          <h3>Team Collaboration</h3>
        </div>

        <div className="gallery-item">
          <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?w=600" alt="Computer hardware" />
          <h3>Computer Technology</h3>
        </div>

        <div className="gallery-item">
          <img src="https://images.unsplash.com/photo-1516321497487-e288fb19713f?w=600" alt="Digital learning" />
          <h3>Digital Learning</h3>
        </div>

      </section>

    </div>
  );
}

export default Gallery;