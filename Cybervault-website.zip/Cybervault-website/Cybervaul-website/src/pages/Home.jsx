import { Link } from "react-router-dom";
import PageIntro from "../components/PageIntro";
import Button from "../components/Button";

function Home() {
  return (
    <div className="home-page">

      <PageIntro
        title="Welcome to Cybervault IT Centre"
        description="Your trusted partner in technology, innovation and digital transformation."
      />

      <section>
        <h2>Technology Without Boundaries</h2>

        <p>
          We provide modern technology solutions that help
          individuals and businesses grow in the digital world.
        </p>

        <p>
          From web development to cybersecurity, we deliver
          reliable and innovative IT services worldwide.
        </p>

        <Link to="/services">
          <Button text="Explore Our Services" />
        </Link>

        <Link to="/registration">
          <Button text="Register With Us" />
        </Link>
      </section>

      <section>
        <h2>Why Choose Cybervault?</h2>

        <ul>
          <li>Professional technology solutions</li>
          <li>Reliable customer support</li>
          <li>Modern and innovative services</li>
          <li>Commitment to quality and security</li>
        </ul>
      </section>

    </div>
  );
}

export default Home;