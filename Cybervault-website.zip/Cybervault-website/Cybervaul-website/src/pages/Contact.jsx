import { useState } from "react";
import PageIntro from "../components/PageIntro";
import Button from "../components/Button";

function Contact() {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [confirmation, setConfirmation] = useState("");

  function handleSubmit(event) {
    event.preventDefault();

    setConfirmation("Thank you! Your message has been received.");

    setName("");
    setEmail("");
    setMessage("");
  }

  return (
    <div className="contact-page">

      <PageIntro
        title="Contact Us"
        description="We would love to hear from you. Get in touch with our team."
      />

      <section>
        <h2>Our Contact Information</h2>

        <p>Email: cybervaultitcentre@gmail.com</p>

        <p>WhatsApp: +254746786602 / +254731343451</p>

        <p>Website: Cybervault IT Centre</p>
      </section>

      <section>
        <h2>Send Us a Message</h2>

        <form onSubmit={handleSubmit}>

          <label>Your Name</label>
          <input
            type="text"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Enter your name"
            required
          />

          <label>Email Address</label>
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="Enter your email"
            required
          />

          <label>Your Message</label>
          <textarea
            value={message}
            onChange={(event) => setMessage(event.target.value)}
            placeholder="Write your message"
            required
          />

          <Button
            text="Send Message"
            type="submit"
          />

        </form>

        {confirmation && <p>{confirmation}</p>}

      </section>

    </div>
  );
}

export default Contact;