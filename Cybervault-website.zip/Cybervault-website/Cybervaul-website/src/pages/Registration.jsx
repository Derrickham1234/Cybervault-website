import { useState } from "react";
import PageIntro from "../components/PageIntro";
import Button from "../components/Button";

function Registration() {

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    service: ""
  });

  const [message, setMessage] = useState("");

  function handleChange(event) {
    setFormData({
      ...formData,
      [event.target.name]: event.target.value
    });
  }

  function handleSubmit(event) {
    event.preventDefault();

    setMessage("Registration successful! Thank you for choosing Cybervault IT Centre.");

    setFormData({
      fullName: "",
      email: "",
      phone: "",
      service: ""
    });
  }

  return (
    <div className="registration-page">

      <PageIntro
        title="Register With Us"
        description="Complete the form below to register for our services."
      />

      <form onSubmit={handleSubmit}>

        <label>Full Name</label>
        <input
          type="text"
          name="fullName"
          value={formData.fullName}
          onChange={handleChange}
          placeholder="Enter your full name"
          required
        />

        <label>Email Address</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Enter your email"
          required
        />

        <label>Phone Number</label>
        <input
          type="tel"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          placeholder="Enter your phone number"
          required
        />

        <label>Select a Service</label>

        <select
          name="service"
          value={formData.service}
          onChange={handleChange}
          required
        >
          <option value="">Choose a service</option>
          <option value="Web Development">Web Development</option>
          <option value="Cybersecurity">Cybersecurity</option>
          <option value="Cloud Management">Cloud Management</option>
          <option value="Application Development">Application Development</option>
          <option value="Database Development">Database Development</option>
          <option value="Android Development">Android Development</option>
        </select>

        <Button
          text="Submit Registration"
          type="submit"
        />

      </form>

      {message && <p>{message}</p>}

    </div>
  );
}

export default Registration;