import PageIntro from "../components/PageIntro";
import ServiceCard from "../components/ServiceCard";

function Services() {
  return (
    <div className="services-page">

      <PageIntro
        title="Our Services"
        description="Explore our professional technology and digital solutions."
      />

      <section className="services-container">

        <ServiceCard
          title="Web Development"
          description="We create responsive and modern websites for businesses and individuals."
        />

        <ServiceCard
          title="Cybersecurity"
          description="We help protect digital systems, networks and information from cyber threats."
        />

        <ServiceCard
          title="Cloud Management"
          description="We provide cloud solutions for secure storage, access and management of data."
        />

        <ServiceCard
          title="Application Development"
          description="We develop useful software applications to solve real-world problems."
        />

        <ServiceCard
          title="Database Development"
          description="We design, develop and manage organized database systems."
        />

        <ServiceCard
          title="Android Development"
          description="We build mobile applications for Android devices."
        />

        <ServiceCard
          title="Search Engine Optimization"
          description="We improve website visibility and help businesses reach more customers online."
        />

        <ServiceCard
          title="Digital Advertising"
          description="We help businesses promote their products and services through digital platforms."
        />

      </section>

    </div>
  );
}

export default Services;