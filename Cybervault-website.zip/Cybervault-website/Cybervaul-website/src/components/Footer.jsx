function Footer() {
  return (
    <footer>
      <h3>Cybervault IT Centre</h3>

      <p>Empowering the world through technology.</p>

      <p>Email: cybervaultitcentre@gmail.com</p>

      <p>WhatsApp: +254746786602 / +254731343451</p>

      <p>
        &copy; {new Date().getFullYear()} Cybervault IT Centre.
        All rights reserved.
      </p>
    </footer>
  );
}

export default Footer;