import { useState } from "react";
import { NavLink } from "react-router-dom";

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header>
      <h2>Cybervault IT Centre</h2>

      <button onClick={() => setMenuOpen(!menuOpen)}>
        {menuOpen ? "Close" : "Menu"}
      </button>

      <nav style={{ display: menuOpen ? "block" : "none" }}>
        <NavLink to="/" onClick={() => setMenuOpen(false)}>Home</NavLink>
        <br />
        <NavLink to="/about" onClick={() => setMenuOpen(false)}>About Us</NavLink>
        <br />
        <NavLink to="/services" onClick={() => setMenuOpen(false)}>Services</NavLink>
        <br />
        <NavLink to="/registration" onClick={() => setMenuOpen(false)}>Registration</NavLink>
        <br />
        <NavLink to="/gallery" onClick={() => setMenuOpen(false)}>Gallery</NavLink>
        <br />
        <NavLink to="/contact" onClick={() => setMenuOpen(false)}>Contact Us</NavLink>
      </nav>
    </header>
  );
}

export default Header;